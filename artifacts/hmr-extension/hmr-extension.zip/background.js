// src/background.ts
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (message.type === "SESSION_SYNC") {
      chrome.storage.local.set({
        session: message.session,
        apiBaseUrl: message.apiBaseUrl
      });
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === "CHECK_AUTH") {
      chrome.storage.local.get(["session", "apiBaseUrl"]).then((data) => {
        const stored = data;
        sendResponse({
          authenticated: !!stored.session?.authToken,
          session: stored.session ?? null
        });
      });
      return true;
    }
    if (message.type === "APPLICATION_DETECTED") {
      handleApplicationDetected(message).then(sendResponse);
      return true;
    }
    return false;
  }
);
async function handleApplicationDetected(msg) {
  const data = await chrome.storage.local.get(["session", "apiBaseUrl", "recentApps"]);
  const session = data.session;
  const apiBaseUrl = data.apiBaseUrl;
  if (!session?.authToken) {
    return { success: false, error: "Not authenticated" };
  }
  if (!apiBaseUrl) {
    return { success: false, error: "No API URL configured" };
  }
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  try {
    const res = await fetch(`${apiBaseUrl}/api/external-applications`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.authToken}`
      },
      body: JSON.stringify({
        jobTitle: msg.jobTitle,
        companyName: msg.companyName,
        platform: msg.platform,
        jobUrl: msg.jobUrl ?? null,
        status: "applied",
        appliedDate: today,
        source: "extension"
      })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return { success: false, error: err.error ?? `HTTP ${res.status}` };
    }
    const newApp = await res.json();
    const existing = data.recentApps ?? [];
    const updated = [
      {
        id: newApp.id,
        jobTitle: newApp.jobTitle,
        companyName: newApp.companyName,
        platform: newApp.platform,
        status: newApp.status,
        appliedDate: newApp.appliedDate,
        createdAt: newApp.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
      },
      ...existing
    ].slice(0, 10);
    await chrome.storage.local.set({ recentApps: updated });
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : "Network error" };
  }
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["session"]).then((data) => {
    const stored = data;
    if (!stored.session) {
    }
  });
});
