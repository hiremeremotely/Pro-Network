"use strict";
(() => {
  // src/content/toast.ts
  function showToast(message, success) {
    const existing = document.getElementById("__hmr_ext_toast__");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "__hmr_ext_toast__";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      padding: "12px 16px",
      borderRadius: "10px",
      fontSize: "13px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "500",
      lineHeight: "1.4",
      maxWidth: "280px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.18)",
      color: "#fff",
      backgroundColor: success ? "#4f46e5" : "#dc2626",
      transition: "opacity 0.3s ease, transform 0.3s ease",
      opacity: "0",
      transform: "translateY(8px)",
      pointerEvents: "none"
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
    });
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(8px)";
      setTimeout(() => toast.remove(), 300);
    }, 3e3);
  }
  function showBadge(nearEl, label = "HMR") {
    if (!nearEl || document.getElementById("__hmr_badge__")) return;
    const badge = document.createElement("span");
    badge.id = "__hmr_badge__";
    badge.textContent = label;
    Object.assign(badge.style, {
      display: "inline-flex",
      alignItems: "center",
      marginLeft: "8px",
      padding: "2px 7px",
      borderRadius: "4px",
      fontSize: "11px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "700",
      color: "#fff",
      backgroundColor: "#4f46e5",
      verticalAlign: "middle",
      letterSpacing: "0.03em",
      flexShrink: "0"
    });
    try {
      nearEl.parentElement?.insertBefore(badge, nearEl.nextSibling);
    } catch {
    }
  }

  // src/content/linkedin.ts
  var applied = false;
  var badgeInjected = false;
  function extractJobInfo() {
    const jobTitle = document.querySelector(".job-details-jobs-unified-top-card__job-title h1")?.innerText?.trim() || document.querySelector(".jobs-unified-top-card__job-title")?.innerText?.trim() || document.querySelector("h1.t-24")?.innerText?.trim() || "Unknown Role";
    const companyName = document.querySelector(".job-details-jobs-unified-top-card__company-name a")?.innerText?.trim() || document.querySelector(".jobs-unified-top-card__company-name")?.innerText?.trim() || document.querySelector(".topcard__org-name-link")?.innerText?.trim() || "Unknown Company";
    return { jobTitle, companyName, jobUrl: window.location.href };
  }
  function injectBadge() {
    if (badgeInjected) return;
    const applyBtn = document.querySelector(
      ".jobs-apply-button--top-card .jobs-apply-button, .jobs-s-apply button, [data-control-name='jobdetails_topcard_inapply']"
    );
    if (applyBtn) {
      showBadge(applyBtn);
      badgeInjected = true;
    }
  }
  function isConfirmationPage() {
    const confirmTexts = [
      "application was sent",
      "application has been submitted",
      "you've applied",
      "thanks for applying",
      "successfully applied"
    ];
    const bodyText = document.body.innerText.toLowerCase();
    return confirmTexts.some((t) => bodyText.includes(t));
  }
  function handleApplicationDetected() {
    if (applied) return;
    applied = true;
    const info = extractJobInfo();
    chrome.runtime.sendMessage({
      type: "APPLICATION_DETECTED",
      jobTitle: info.jobTitle,
      companyName: info.companyName,
      platform: "linkedin",
      jobUrl: info.jobUrl
    }, (response) => {
      if (response?.success) {
        showToast("Logged to Hire Me Remotely \u2713", true);
      } else if (response?.error && response.error !== "Not authenticated" && response.error !== "No API URL configured") {
        showToast("Could not log application", false);
      }
    });
  }
  var observer = new MutationObserver(() => {
    injectBadge();
    if (!applied && isConfirmationPage()) {
      handleApplicationDetected();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
  injectBadge();
  if (isConfirmationPage()) {
    handleApplicationDetected();
  }
})();
