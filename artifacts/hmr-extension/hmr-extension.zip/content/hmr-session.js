"use strict";
(() => {
  // src/content/hmr-session.ts
  (function() {
    const SESSION_KEY = "app_user_session";
    function syncSession() {
      try {
        const raw = localStorage.getItem(SESSION_KEY);
        if (!raw) {
          chrome.runtime.sendMessage({ type: "SESSION_CLEAR" });
          return;
        }
        const session = JSON.parse(raw);
        if (!session?.authToken) return;
        chrome.runtime.sendMessage({
          type: "SESSION_SYNC",
          session,
          apiBaseUrl: window.location.origin
        });
      } catch {
      }
    }
    syncSession();
    const origSetItem = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function(key, value) {
      origSetItem(key, value);
      if (key === SESSION_KEY) {
        setTimeout(syncSession, 100);
      }
    };
    const origRemoveItem = localStorage.removeItem.bind(localStorage);
    localStorage.removeItem = function(key) {
      origRemoveItem(key);
      if (key === SESSION_KEY) {
        chrome.runtime.sendMessage({ type: "SESSION_CLEAR" });
      }
    };
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        syncSession();
      }
    });
  })();
})();
