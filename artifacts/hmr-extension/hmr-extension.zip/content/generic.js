"use strict";
(() => {
  // src/content/toast.ts
  function showToast(message, success) {
    const existing = document.getElementById("__hmr_ext_toast__");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "__hmr_ext_toast__";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      padding: "12px 16px",
      borderRadius: "10px",
      fontSize: "13px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "500",
      lineHeight: "1.4",
      maxWidth: "280px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.18)",
      color: "#fff",
      backgroundColor: success ? "#4f46e5" : "#dc2626",
      transition: "opacity 0.3s ease, transform 0.3s ease",
      opacity: "0",
      transform: "translateY(8px)",
      pointerEvents: "none"
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
    });
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(8px)";
      setTimeout(() => toast.remove(), 300);
    }, 3e3);
  }

  // src/content/generic.ts
  var applied = false;
  function shouldActivate() {
    const url = window.location.href.toLowerCase();
    return url.includes("/apply/") || url.includes("/applied") || url.includes("/application/confirm") || url.includes("/application-submitted") || url.includes("/jobs/apply");
  }
  function isConfirmationPage() {
    if (!shouldActivate()) return false;
    const confirmTexts = [
      "application submitted",
      "application was sent",
      "you've applied",
      "thanks for applying",
      "successfully applied",
      "application complete",
      "your application has been",
      "we've received your application",
      "application received"
    ];
    const bodyText = document.body.innerText.toLowerCase();
    return confirmTexts.some((t) => bodyText.includes(t));
  }
  function extractJobInfo() {
    const jobTitle = document.querySelector("h1")?.innerText?.trim() || document.querySelector("[class*='job-title'], [class*='jobTitle'], [class*='position']")?.innerText?.trim() || document.title.split(" - ")[0]?.trim() || "Unknown Role";
    const companyName = document.querySelector("[class*='company-name'], [class*='companyName'], [class*='employer']")?.innerText?.trim() || document.title.split(" - ")[1]?.trim() || new URL(window.location.href).hostname.replace("www.", "").split(".")[0] || "Unknown Company";
    return { jobTitle, companyName };
  }
  function handleApplicationDetected() {
    if (applied) return;
    applied = true;
    const info = extractJobInfo();
    const platform = new URL(window.location.href).hostname.replace("www.", "").split(".")[0] || "other";
    chrome.runtime.sendMessage({
      type: "APPLICATION_DETECTED",
      jobTitle: info.jobTitle,
      companyName: info.companyName,
      platform,
      jobUrl: window.location.href
    }, (response) => {
      if (response?.success) {
        showToast("Logged to Hire Me Remotely \u2713", true);
      }
    });
  }
  if (shouldActivate()) {
    const observer = new MutationObserver(() => {
      if (!applied && isConfirmationPage()) {
        handleApplicationDetected();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    if (isConfirmationPage()) {
      handleApplicationDetected();
    }
  }
})();
