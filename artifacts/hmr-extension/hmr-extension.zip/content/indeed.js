"use strict";
(() => {
  // src/content/toast.ts
  function showToast(message, success) {
    const existing = document.getElementById("__hmr_ext_toast__");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "__hmr_ext_toast__";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      padding: "12px 16px",
      borderRadius: "10px",
      fontSize: "13px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "500",
      lineHeight: "1.4",
      maxWidth: "280px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.18)",
      color: "#fff",
      backgroundColor: success ? "#4f46e5" : "#dc2626",
      transition: "opacity 0.3s ease, transform 0.3s ease",
      opacity: "0",
      transform: "translateY(8px)",
      pointerEvents: "none"
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
    });
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(8px)";
      setTimeout(() => toast.remove(), 300);
    }, 3e3);
  }
  function showBadge(nearEl, label = "HMR") {
    if (!nearEl || document.getElementById("__hmr_badge__")) return;
    const badge = document.createElement("span");
    badge.id = "__hmr_badge__";
    badge.textContent = label;
    Object.assign(badge.style, {
      display: "inline-flex",
      alignItems: "center",
      marginLeft: "8px",
      padding: "2px 7px",
      borderRadius: "4px",
      fontSize: "11px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "700",
      color: "#fff",
      backgroundColor: "#4f46e5",
      verticalAlign: "middle",
      letterSpacing: "0.03em",
      flexShrink: "0"
    });
    try {
      nearEl.parentElement?.insertBefore(badge, nearEl.nextSibling);
    } catch {
    }
  }

  // src/content/indeed.ts
  var applied = false;
  var badgeInjected = false;
  function extractJobInfo() {
    const jobTitle = document.querySelector(".jobsearch-JobInfoHeader-title span")?.innerText?.trim() || document.querySelector("h1.jobsearch-JobInfoHeader-title")?.innerText?.trim() || document.querySelector("[data-testid='jobsearch-JobInfoHeader-title']")?.innerText?.trim() || "Unknown Role";
    const companyName = document.querySelector("[data-testid='inlineHeader-companyName']")?.innerText?.trim() || document.querySelector(".jobsearch-InlineCompanyRating-companyName")?.innerText?.trim() || document.querySelector(".css-1ioi40n")?.innerText?.trim() || "Unknown Company";
    return { jobTitle, companyName, jobUrl: window.location.href };
  }
  function injectBadge() {
    if (badgeInjected) return;
    const applyBtn = document.querySelector(
      "[data-testid='applyButton'], .ia-IndeedApplyButton, button[id='indeedApplyButton']"
    );
    if (applyBtn) {
      showBadge(applyBtn);
      badgeInjected = true;
    }
  }
  function isConfirmationPage() {
    const url = window.location.href;
    if (url.includes("applied=1") || url.includes("/viewjob") && url.includes("applied")) return true;
    const confirmTexts = [
      "application was submitted",
      "you've applied",
      "your application has been sent",
      "thanks for applying",
      "application submitted",
      "successfully applied"
    ];
    const bodyText = document.body.innerText.toLowerCase();
    return confirmTexts.some((t) => bodyText.includes(t));
  }
  function handleApplicationDetected() {
    if (applied) return;
    applied = true;
    const info = extractJobInfo();
    chrome.runtime.sendMessage({
      type: "APPLICATION_DETECTED",
      jobTitle: info.jobTitle,
      companyName: info.companyName,
      platform: "indeed",
      jobUrl: info.jobUrl
    }, (response) => {
      if (response?.success) {
        showToast("Logged to Hire Me Remotely \u2713", true);
      }
    });
  }
  var observer = new MutationObserver(() => {
    injectBadge();
    if (!applied && isConfirmationPage()) {
      handleApplicationDetected();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
  var lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      applied = false;
      badgeInjected = false;
      setTimeout(() => {
        injectBadge();
        if (isConfirmationPage()) handleApplicationDetected();
      }, 1500);
    }
  }, 1e3);
  injectBadge();
  if (isConfirmationPage()) handleApplicationDetected();
})();
